function [y1,y2] = Functions(x1, x2)
    y1 = x1*x1;
    y2 = x2*x2;
end
